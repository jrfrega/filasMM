## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
# Carregue o pacote correspondente antes de compilar a vignette
library(filasMM)

## ----problema8, eval=FALSE----------------------------------------------------
# f <- filaMMc(lambda = 0.3, mu = 1/2, c = 1, tmax = 10)
# 
# # Taxa de ocupação do sistema (rho)
# f$rho
# 
# # Número médio de clientes no sistema (L)
# f$L
# 
# # Número médio de clientes na fila (Lq)
# f$Lq
# 
# # Probabilidade de o sistema estar vazio (P0)
# f$P0
# 
# # Tempo médio de espera de um cliente na fila (Wq, em minutos)
# f$Wq
# 
# # Tempo médio de permanência de um cliente no sistema (W, em minutos)
# f$W
# 
# # Probabilidade de um cliente ter que aguardar pelo atendimento por mais de 10 minutos
# 1 - f$ptmax
# 
# # Probabilidade de haver mais de cinco clientes na fila (clientes esperando na rua, ou seja, n > 6 no sistema)
# 1 - f$P0 - sum(f$Pn[1:6])

## ----problema9_parte1, eval=FALSE---------------------------------------------
# f <- filaMMcK(lambda = 0.3, mu = 1/2, c = 1, k = 6, tmax = 10)
# 
# # Probabilidade de o sistema estar vazio
# f$P0
# 
# # Número médio de clientes no sistema
# f$L
# 
# # Número médio de clientes na fila
# f$Lq
# 
# # Probabilidade de existir seis clientes no sistema (lotação máxima)
# f$Pn[6]
# 
# # Tempo médio de permanência no sistema
# f$W
# 
# # Tempo médio de espera na fila
# f$Wq
# 
# # Taxa de rejeição horária (clientes perdidos por hora)
# f$lambdaPk * 60

## ----problema9_parte2, eval=FALSE---------------------------------------------
# f <- filaMMcK(lambda = 1.5 * 0.3, mu = 1/2, c = 1, k = 6, tmax = 10)
# 
# # Novo tempo médio de espera na fila
# f$Wq
# 
# # Taxa de rejeição diária (considerando 6 horas de funcionamento por dia)
# f$lambdaPk * 60 * 6

## ----problema10, eval=FALSE---------------------------------------------------
# f <- filaMMc(lambda = 4 * 0.3, mu = 1/2, c = 1 + 2, tmax = 2)
# 
# # Taxa de ocupação do sistema
# f$rho
# 
# # Número médio de clientes no sistema
# f$L
# 
# # Número médio de clientes na fila
# f$Lq
# 
# # Probabilidade de o sistema estar vazio
# f$P0
# 
# # Probabilidade de se iniciar uma fila (haver mais de 3 clientes no sistema)
# 1 - f$P0 - sum(f$Pn[1:3])
# 
# # Tempo médio de espera de um cliente na fila
# f$Wq
# 
# # Tempo médio de permanência de um cliente no sistema
# f$W
# 
# # Probabilidade de um cliente ter que aguardar pelo atendimento por mais de 2 minutos
# 1 - f$ptmax
# 
# # Probabilidade de pelo menos um caixa estar ocioso
# f$pocioso
# 
# # Probabilidade de um cliente não ter que aguardar por atendimento (0, 1 ou 2 clientes no sistema)
# f$P0 + sum(f$Pn[1:2])

## ----problema11, eval=FALSE---------------------------------------------------
# f <- filaMMcK(lambda = 1/7.5, mu = 1/20, c = 3, k = 7, tmax = 2)
# 
# # Probabilidade de a emergência se encontrar lotada (7 pacientes)
# f$Pn[7]
# 
# # Perda de pacientes por hora (taxa de rejeição horária)
# f$lambdaPk * 60
# 
# # Probabilidade de que um paciente seja imediatamente atendido (0, 1 ou 2 pacientes presentes)
# f$P0 + sum(f$Pn[1:2])
# 
# # Média diária (24 horas) de pacientes que deixam de ser atendidos
# f$lambdaPk * 60 * 24
# 
# # Número médio de pacientes em atendimento simultâneo
# f$L - f$Lq
# 
# # Tempo médio (em minutos) que um paciente deve esperar até iniciar o atendimento
# f$Wq

## ----problema12, eval=FALSE---------------------------------------------------
# f <- filaMMcKK(lambda = 1/4, mu = 1/2, c = 3, k = 15, tmax = 2)
# 
# # Probabilidade de todos os mecânicos estarem ocupados
# 1 - f$pocioso
# 
# # Número médio de ônibus esperando conserto (na fila)
# f$Lq
# 
# # Número médio de ônibus na oficina (em conserto + na fila)
# f$L
# 
# # Tempo médio (em dias) que um ônibus fica fora de circulação
# f$W
# 
# # Probabilidade de que todos os 15 ônibus estejam fora de circulação
# f$Pn[15]
# 
# # Probabilidade de que nenhum ônibus esteja fora de circulação (frota 100% ativa)
# f$P0
# 
# # Número médio de ônibus em circulação
# sum(15:0 * c(f$P0, f$Pn))
# 
# # Probabilidade de que existam menos da metade dos ônibus em circulação (8 ou mais na oficina)
# sum(f$Pn[8:15])

